package exceptionPack;

 class Manager
 {
	int mId;
	String mName;
	void addManager()
	{
		mId=201;
		mName="RAHUL";
	}
	void displayManager()
	{
		System.out.println("Manager Id is: "+mId);
		System.out.println("Manager Nmae is: "+mName);
	}
	}
	class clerk extends Manager
	{
		int cId;
		String cName;
		void addclerk()
		{
			cId=10;
			cName="ARUN";
		}
		void displayclerk()
		{
			System.out.println("clerk Id is: "+cId);
			System.out.println("clerk Nmae is: "+cName);
		}
		@Override
		void addManager()
		{
			for(int i=65; i<=90; i++)
			{
				System.out.println((char)i);
			}
		}
	}
		public class ExmpClass
		{
			public static void main(String[] args)
			{
				clerk c=new clerk();//here object of Manager is not required
				c.addManager();
				c.displayManager();
				c.addclerk();
				c.displayclerk();
				System.out.println(c.toString());
			}
	}
