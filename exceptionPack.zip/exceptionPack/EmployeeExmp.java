package exceptionPack;

public class EmployeeExmp {
int id;
String name;
public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		EmployeeExmp employeeExmp= new EmployeeExmp();
		employeeExmp.accept();
	}
	void accept()
	{
		try
		{
			int ar[]=new int[10];
			ar[0]=20;
			ar[1]=25;
			System.out.println(ar[14]);
		}
		catch(Exception e)
		{
			System.out.println("Exception Handled..."+e);
		}
		finally
		{
			System.out.println(id);
			int a,b;
			a=15;
			b=20;
			b+=50;
			a-=80;
			System.out.println(a);
			System.out.println(b);
		}
	}

}
