package exceptionPack;

public class StudentImpl extends StudentExmp
{
	String id,name;
	public void addStudent()
	{
		id="s171113400062";
		name="RAHUL";
	}
	public void printStudent()
	{
		System.out.println("Student id is "+id);
		System.out.println("Student name is "+name);
	}
	
public static void main(String[] args) {
		// TODO Auto-generated method stub
	StudentImpl stImpl=new StudentImpl();
	stImpl.addStudent();
	stImpl.printStudent();
	StudentExmp st= new StudentImpl();
	st.addStudent();
	st.printStudent();
	}
}


	


