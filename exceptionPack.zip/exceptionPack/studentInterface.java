package exceptionPack;

public interface studentInterface {
	public void addstudent();
	public void printstudent();
	//interface will not allow function body

}
